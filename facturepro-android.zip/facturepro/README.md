# FacturePro – Canadian Invoice Generator (Pro quality)

High-quality freemium invoice generator optimized for Canada.

## Features vs competitors
- Live invoice preview
- Canadian tax presets (GST/HST by province + QC QST)
- Interac e-Transfer field
- Business Number + GST/HST number
- Quick templates (Consultant, Trades, Creative, General)
- Multi-language: English / Français / Español
- CAD default (+ USD / EUR)
- Professional PDF export
- Freemium: 5 free invoices/month + watermark
- Pro: $9 CAD/mo or $79 CAD/yr via Stripe

## Prices (kept)
- Monthly: **$9 CAD**
- Yearly: **$79 CAD**

## Deploy / Update on Vercel
1. Upload this folder (or push to Git)
2. Ensure these Environment Variables exist:
   - `STRIPE_SECRET_KEY`
   - `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` (optional for client)
   - `STRIPE_PRICE_MONTHLY`
   - `STRIPE_PRICE_YEARLY`
3. Redeploy

## Local
```bash
npm install
npm run dev
```
