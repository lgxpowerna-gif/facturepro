# Activer les paiements Stripe – FacturePro

## 1. Créer les produits dans Stripe

1. Va sur https://dashboard.stripe.com/products
2. **Create product** → Nom : `FacturePro Pro Monthly`
   - Pricing : **Recurring** → $9.00 CAD / month
   - Copie le **Price ID** (commence par `price_...`)
3. **Create product** → Nom : `FacturePro Pro Yearly`
   - Pricing : **Recurring** → $79.00 CAD / year
   - Copie le **Price ID**

## 2. Récupérer les clés API

https://dashboard.stripe.com/apikeys

- **Publishable key** → `pk_live_...` ou `pk_test_...`
- **Secret key** → `sk_live_...` ou `sk_test_...`

## 3. Ajouter les variables dans Vercel

1. Vercel → ton projet → **Settings** → **Environment Variables**
2. Ajoute exactement :

| Name | Value |
|------|-------|
| `STRIPE_SECRET_KEY` | `sk_live_...` (ou sk_test_...) |
| `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | `pk_live_...` |
| `STRIPE_PRICE_MONTHLY` | `price_...` (mensuel) |
| `STRIPE_PRICE_YEARLY` | `price_...` (annuel) |

3. **Save** puis **Redeploy** le projet (Deployments → ⋯ → Redeploy)

## 4. Tester

- Mode **Test** d’abord (clés `sk_test_` / `pk_test_`)
- Carte de test Stripe : `4242 4242 4242 4242` – n’importe quelle date future – CVC 123
- Après paiement réussi → l’utilisateur revient sur le site avec `?success=true` et passe en Pro

## 5. Webhook (optionnel mais recommandé)

Pour activer automatiquement le plan Pro même si l’utilisateur ferme la page :

1. Stripe → Developers → Webhooks → Add endpoint
2. URL : `https://TON-DOMAINE.vercel.app/api/webhook`
3. Event : `checkout.session.completed`
4. (Le fichier webhook est prêt à être complété si besoin)

## C’est tout

Les boutons « Passer à Pro » redirigent maintenant vers le vrai Checkout Stripe.
