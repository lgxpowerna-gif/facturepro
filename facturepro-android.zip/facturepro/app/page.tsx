"use client";

import { useState, useEffect, useMemo, useCallback } from "react";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";

/* ───────────────────────── Types ───────────────────────── */
interface LineItem {
  id: number;
  description: string;
  quantity: number;
  unitPrice: number;
}

interface SavedInvoice {
  id: string;
  number: string;
  clientName: string;
  total: number;
  date: string;
  createdAt: string;
}

type Plan = "free" | "pro";
type Lang = "en" | "fr" | "es";
type Currency = "CAD" | "USD" | "EUR";
type View = "app" | "pricing" | "history";

/* ───────────────────────── Tax presets (Canada) ───────────────────────── */
const TAX_PRESETS = [
  { id: "none", label: "No tax", rate: 0, name: "" },
  { id: "gst", label: "GST 5%", rate: 5, name: "GST" },
  { id: "hst-on", label: "HST 13% (ON)", rate: 13, name: "HST" },
  { id: "hst-nb", label: "HST 15% (NB/NL/NS/PE)", rate: 15, name: "HST" },
  { id: "gst-pst-bc", label: "GST+PST 12% (BC)", rate: 12, name: "GST+PST" },
  { id: "gst-qst-qc", label: "GST+QST 14.975% (QC)", rate: 14.975, name: "GST+QST" },
  { id: "gst-pst-sk", label: "GST+PST 11% (SK)", rate: 11, name: "GST+PST" },
  { id: "gst-rst-mb", label: "GST+RST 12% (MB)", rate: 12, name: "GST+RST" },
  { id: "custom", label: "Custom rate", rate: 0, name: "Tax" },
];

/* ───────────────────────── Templates ───────────────────────── */
const TEMPLATES = [
  {
    id: "general",
    label: { en: "General", fr: "Général", es: "General" },
    desc: { en: "Any business", fr: "Toute entreprise", es: "Cualquier negocio" },
    items: [{ description: "Professional services", quantity: 1, unitPrice: 0 }],
  },
  {
    id: "consultant",
    label: { en: "Consultant", fr: "Consultant", es: "Consultor" },
    desc: { en: "Hourly / retainer", fr: "Horaire / forfait", es: "Por hora / retainer" },
    items: [{ description: "Consulting services – 10 hours @ $95/hr", quantity: 10, unitPrice: 95 }],
  },
  {
    id: "trades",
    label: { en: "Trades", fr: "Métiers", es: "Oficios" },
    desc: { en: "Labour + materials", fr: "Main-d'œuvre + matériaux", es: "Mano de obra + materiales" },
    items: [
      { description: "Labour", quantity: 1, unitPrice: 0 },
      { description: "Materials", quantity: 1, unitPrice: 0 },
    ],
  },
  {
    id: "creative",
    label: { en: "Creative", fr: "Créatif", es: "Creativo" },
    desc: { en: "Deposit / milestone", fr: "Acompte / jalon", es: "Depósito / hito" },
    items: [{ description: "Project deposit (50%)", quantity: 1, unitPrice: 0 }],
  },
];

/* ───────────────────────── i18n ───────────────────────── */
const translations = {
  en: {
    brand: "FacturePro",
    free: "Free plan",
    proBadge: "Pro",
    create: "Create",
    history: "History",
    pricing: "Pricing",
    upgrade: "Upgrade to Pro",
    proAccount: "Pro account",
    invoicesThisMonth: "invoices this month",
    limitReachedTitle: "Free limit reached",
    limitReachedText: "You've used your {limit} free invoices this month. Upgrade to Pro for unlimited invoices, no watermark, and logo.",
    monthly: "Pro Monthly – $9/mo",
    yearly: "Pro Yearly – $79/yr",
    yearlyBonus: "(2 months free)",
    continueFree: "Continue free",
    pricingTitle: "Simple pricing",
    pricingSub: "Start free. Upgrade when you're ready.",
    freePlan: "Free",
    freePrice: "$0",
    freeDesc: "Perfect to get started",
    proPlan: "Pro",
    proPrice: "$9",
    perMonth: "/mo",
    orYearly: "or $79/year (save $29)",
    cancelAnytime: "Cancel anytime",
    feature5: "5 invoices / month",
    featureTax: "Canadian tax presets",
    featurePdf: "PDF export",
    featureWatermark: "Watermark on PDF",
    featureLogo: "Custom logo",
    featureTemplates: "Premium templates",
    featureUnlimited: "Unlimited invoices",
    featureNoWatermark: "No watermark",
    featureLogoColors: "Logo + branding",
    feature3Templates: "All templates",
    featureHistory: "Unlimited history",
    featureSupport: "Priority support",
    featureInterac: "Interac instructions",
    startMonthly: "Start – $9/mo",
    startYearly: "Yearly – $79 (best value)",
    socialProof: "Built for Canadian freelancers & small businesses",
    secure: "Secure Stripe payments",
    hosted: "Hosted in Canada region",
    compliant: "GST/HST ready",
    historyTitle: "Invoice history",
    historyLimit: "Last 50 (Pro = unlimited)",
    noInvoices: "No invoices yet.",
    createFirst: "Create your first invoice →",
    number: "No.",
    client: "Client",
    date: "Date",
    totalTTC: "Total",
    yourCompany: "Your business",
    clientSection: "Bill to",
    invoiceSection: "Invoice details",
    items: "Line items",
    addLine: "+ Add item",
    notes: "Notes / Payment terms",
    summary: "Summary",
    taxRate: "Tax",
    totalHT: "Subtotal",
    tax: "Tax",
    total: "Total",
    usedThisMonth: "used this month",
    downloadPdf: "Download PDF",
    upgradeToContinue: "Upgrade to continue",
    freeWatermark: "Free plan includes a small watermark",
    goPro: "Go Pro",
    goProDesc: "Unlimited • No watermark • Logo • Templates",
    seePricing: "See pricing",
    companyName: "Business name",
    address: "Address",
    city: "City / Postal code",
    email: "Email",
    phone: "Phone",
    siret: "Business Number (BN)",
    gstNumber: "GST/HST number",
    interac: "Interac e-Transfer email",
    clientName: "Client name",
    invoiceNumber: "Invoice number",
    dueDate: "Due date",
    template: "Quick templates",
    description: "Description",
    qty: "Qty",
    unitPrice: "Rate",
    logoPro: "Logo (Pro)",
    logoLocked: "Custom logo → Pro",
    footerTagline: "Professional invoices for Canadian businesses",
    rights: "All rights reserved",
    popular: "BEST VALUE",
    currency: "Currency",
    language: "Language",
    livePreview: "Live preview",
    paymentTerms: "Payment terms",
    balanceDue: "Balance due",
    billFrom: "From",
    billTo: "Bill to",
    applyTemplate: "Use",
    remove: "Remove",
  },
  fr: {
    brand: "FacturePro",
    free: "Plan gratuit",
    proBadge: "Pro",
    create: "Créer",
    history: "Historique",
    pricing: "Tarifs",
    upgrade: "Passer à Pro",
    proAccount: "Compte Pro",
    invoicesThisMonth: "factures ce mois",
    limitReachedTitle: "Limite gratuite atteinte",
    limitReachedText: "Vous avez utilisé vos {limit} factures gratuites ce mois-ci. Passez à Pro pour des factures illimitées, sans filigrane et avec logo.",
    monthly: "Pro Mensuel – 9 $/mois",
    yearly: "Pro Annuel – 79 $/an",
    yearlyBonus: "(2 mois offerts)",
    continueFree: "Continuer en gratuit",
    pricingTitle: "Tarifs simples",
    pricingSub: "Commencez gratuitement. Passez à Pro quand vous voulez.",
    freePlan: "Gratuit",
    freePrice: "0 $",
    freeDesc: "Parfait pour démarrer",
    proPlan: "Pro",
    proPrice: "9 $",
    perMonth: "/mois",
    orYearly: "ou 79 $/an (économie de 29 $)",
    cancelAnytime: "Annulable à tout moment",
    feature5: "5 factures / mois",
    featureTax: "Presets taxes canadiennes",
    featurePdf: "Export PDF",
    featureWatermark: "Filigrane sur le PDF",
    featureLogo: "Logo personnalisé",
    featureTemplates: "Templates premium",
    featureUnlimited: "Factures illimitées",
    featureNoWatermark: "Sans filigrane",
    featureLogoColors: "Logo + branding",
    feature3Templates: "Tous les templates",
    featureHistory: "Historique illimité",
    featureSupport: "Support prioritaire",
    featureInterac: "Instructions Interac",
    startMonthly: "Démarrer – 9 $/mois",
    startYearly: "Annuel – 79 $ (meilleure offre)",
    socialProof: "Conçu pour les freelances et PME canadiennes",
    secure: "Paiements sécurisés Stripe",
    hosted: "Hébergé région Canada",
    compliant: "Prêt GST/HST",
    historyTitle: "Historique des factures",
    historyLimit: "50 dernières (Pro = illimité)",
    noInvoices: "Aucune facture pour le moment.",
    createFirst: "Créer ma première facture →",
    number: "N°",
    client: "Client",
    date: "Date",
    totalTTC: "Total",
    yourCompany: "Votre entreprise",
    clientSection: "Facturer à",
    invoiceSection: "Détails de la facture",
    items: "Lignes",
    addLine: "+ Ajouter",
    notes: "Notes / Conditions de paiement",
    summary: "Récapitulatif",
    taxRate: "Taxe",
    totalHT: "Sous-total",
    tax: "Taxe",
    total: "Total",
    usedThisMonth: "utilisées ce mois",
    downloadPdf: "Télécharger PDF",
    upgradeToContinue: "Passer à Pro pour continuer",
    freeWatermark: "Le plan gratuit inclut un petit filigrane",
    goPro: "Passer à Pro",
    goProDesc: "Illimité • Sans filigrane • Logo • Templates",
    seePricing: "Voir les tarifs",
    companyName: "Nom de l'entreprise",
    address: "Adresse",
    city: "Ville / Code postal",
    email: "Email",
    phone: "Téléphone",
    siret: "Numéro d'entreprise (NE)",
    gstNumber: "N° GST/HST",
    interac: "Email Interac e-Transfer",
    clientName: "Nom du client",
    invoiceNumber: "N° de facture",
    dueDate: "Échéance",
    template: "Templates rapides",
    description: "Description",
    qty: "Qté",
    unitPrice: "Prix",
    logoPro: "Logo (Pro)",
    logoLocked: "Logo personnalisé → Pro",
    footerTagline: "Factures professionnelles pour entreprises canadiennes",
    rights: "Tous droits réservés",
    popular: "MEILLEURE OFFRE",
    currency: "Devise",
    language: "Langue",
    livePreview: "Aperçu en direct",
    paymentTerms: "Conditions de paiement",
    balanceDue: "Solde dû",
    billFrom: "De",
    billTo: "Facturer à",
    applyTemplate: "Utiliser",
    remove: "Supprimer",
  },
  es: {
    brand: "FacturePro",
    free: "Plan gratuito",
    proBadge: "Pro",
    create: "Crear",
    history: "Historial",
    pricing: "Precios",
    upgrade: "Pasar a Pro",
    proAccount: "Cuenta Pro",
    invoicesThisMonth: "facturas este mes",
    limitReachedTitle: "Límite gratuito alcanzado",
    limitReachedText: "Has usado tus {limit} facturas gratuitas este mes. Pasa a Pro para facturas ilimitadas, sin marca de agua y con logo.",
    monthly: "Pro Mensual – 9 $/mes",
    yearly: "Pro Anual – 79 $/año",
    yearlyBonus: "(2 meses gratis)",
    continueFree: "Continuar gratis",
    pricingTitle: "Precios simples",
    pricingSub: "Empieza gratis. Mejora cuando quieras.",
    freePlan: "Gratis",
    freePrice: "0 $",
    freeDesc: "Perfecto para empezar",
    proPlan: "Pro",
    proPrice: "9 $",
    perMonth: "/mes",
    orYearly: "o 79 $/año (ahorra 29 $)",
    cancelAnytime: "Cancela cuando quieras",
    feature5: "5 facturas / mes",
    featureTax: "Presets de impuestos canadienses",
    featurePdf: "Exportar PDF",
    featureWatermark: "Marca de agua en el PDF",
    featureLogo: "Logo personalizado",
    featureTemplates: "Plantillas premium",
    featureUnlimited: "Facturas ilimitadas",
    featureNoWatermark: "Sin marca de agua",
    featureLogoColors: "Logo + branding",
    feature3Templates: "Todas las plantillas",
    featureHistory: "Historial ilimitado",
    featureSupport: "Soporte prioritario",
    featureInterac: "Instrucciones Interac",
    startMonthly: "Empezar – 9 $/mes",
    startYearly: "Anual – 79 $ (mejor valor)",
    socialProof: "Hecho para freelancers y pymes canadienses",
    secure: "Pagos seguros con Stripe",
    hosted: "Alojado en región Canadá",
    compliant: "Listo para GST/HST",
    historyTitle: "Historial de facturas",
    historyLimit: "Últimas 50 (Pro = ilimitado)",
    noInvoices: "Ninguna factura todavía.",
    createFirst: "Crear mi primera factura →",
    number: "N.º",
    client: "Cliente",
    date: "Fecha",
    totalTTC: "Total",
    yourCompany: "Tu empresa",
    clientSection: "Facturar a",
    invoiceSection: "Detalles de la factura",
    items: "Conceptos",
    addLine: "+ Añadir",
    notes: "Notas / Condiciones de pago",
    summary: "Resumen",
    taxRate: "Impuesto",
    totalHT: "Subtotal",
    tax: "Impuesto",
    total: "Total",
    usedThisMonth: "usadas este mes",
    downloadPdf: "Descargar PDF",
    upgradeToContinue: "Pasar a Pro para continuar",
    freeWatermark: "El plan gratuito incluye una pequeña marca de agua",
    goPro: "Pasar a Pro",
    goProDesc: "Ilimitado • Sin marca de agua • Logo • Plantillas",
    seePricing: "Ver precios",
    companyName: "Nombre de la empresa",
    address: "Dirección",
    city: "Ciudad / Código postal",
    email: "Email",
    phone: "Teléfono",
    siret: "Número de empresa",
    gstNumber: "N.º GST/HST",
    interac: "Email Interac e-Transfer",
    clientName: "Nombre del cliente",
    invoiceNumber: "N.º de factura",
    dueDate: "Vencimiento",
    template: "Plantillas rápidas",
    description: "Descripción",
    qty: "Cant.",
    unitPrice: "Precio",
    logoPro: "Logo (Pro)",
    logoLocked: "Logo personalizado → Pro",
    footerTagline: "Facturas profesionales para negocios canadienses",
    rights: "Todos los derechos reservados",
    popular: "MEJOR VALOR",
    currency: "Moneda",
    language: "Idioma",
    livePreview: "Vista previa",
    paymentTerms: "Condiciones de pago",
    balanceDue: "Saldo adeudado",
    billFrom: "De",
    billTo: "Facturar a",
    applyTemplate: "Usar",
    remove: "Eliminar",
  },
};

/* ───────────────────────── Component ───────────────────────── */
export default function Home() {
  const [view, setView] = useState<View>("app");
  const [plan, setPlan] = useState<Plan>("free");
  const [lang, setLang] = useState<Lang>("en");
  const [currency, setCurrency] = useState<Currency>("CAD");
  const [invoicesThisMonth, setInvoicesThisMonth] = useState(0);
  const [savedInvoices, setSavedInvoices] = useState<SavedInvoice[]>([]);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [loadingCheckout, setLoadingCheckout] = useState(false);
  const [taxPreset, setTaxPreset] = useState("hst-on");
  const [customTaxRate, setCustomTaxRate] = useState(0);
  const [discountPct, setDiscountPct] = useState(0);
  const [toast, setToast] = useState<string | null>(null);

  const t = translations[lang];

  const [company, setCompany] = useState({
    name: "",
    address: "",
    city: "",
    email: "",
    phone: "",
    bn: "",
    gst: "",
    interac: "",
  });

  const [client, setClient] = useState({
    name: "",
    address: "",
    city: "",
    email: "",
  });

  const [invoiceMeta, setInvoiceMeta] = useState({
    number: `INV-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9000) + 1000)}`,
    date: new Date().toISOString().split("T")[0],
    dueDate: "",
    notes: "Payment due within 30 days. Thank you for your business.",
  });

  const [items, setItems] = useState<LineItem[]>([
    { id: 1, description: "", quantity: 1, unitPrice: 0 },
  ]);

  /* ─── Persist ─── */
  useEffect(() => {
    try {
      const sp = localStorage.getItem("fp_plan") as Plan | null;
      const sc = localStorage.getItem("fp_count");
      const si = localStorage.getItem("fp_invoices");
      const sco = localStorage.getItem("fp_company");
      const sl = localStorage.getItem("fp_lang") as Lang | null;
      const scu = localStorage.getItem("fp_currency") as Currency | null;
      if (sp) setPlan(sp);
      if (sc) setInvoicesThisMonth(parseInt(sc, 10) || 0);
      if (si) setSavedInvoices(JSON.parse(si));
      if (sco) setCompany(JSON.parse(sco));
      if (sl && ["en", "fr", "es"].includes(sl)) setLang(sl);
      if (scu && ["CAD", "USD", "EUR"].includes(scu)) setCurrency(scu);
    } catch {
      /* ignore corrupt storage */
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem("fp_plan", plan);
      localStorage.setItem("fp_count", String(invoicesThisMonth));
      localStorage.setItem("fp_invoices", JSON.stringify(savedInvoices));
      localStorage.setItem("fp_company", JSON.stringify(company));
      localStorage.setItem("fp_lang", lang);
      localStorage.setItem("fp_currency", currency);
    } catch {
      /* ignore */
    }
  }, [plan, invoicesThisMonth, savedInvoices, company, lang, currency]);

  /* Success return from Stripe */
  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    if (params.get("success") === "true") {
      setPlan("pro");
      setShowUpgrade(false);
      window.history.replaceState({}, "", window.location.pathname);
    }
  }, []);

  /* Default notes by language */
  useEffect(() => {
    const defaults: Record<Lang, string> = {
      en: "Payment due within 30 days. Thank you for your business.",
      fr: "Paiement à 30 jours. Merci de votre confiance.",
      es: "Pago a 30 días. Gracias por su confianza.",
    };
    setInvoiceMeta((prev) => ({ ...prev, notes: defaults[lang] }));
  }, [lang]);

  const FREE_LIMIT = 5;
  const isLimitReached = plan === "free" && invoicesThisMonth >= FREE_LIMIT;

  const activeTax = useMemo(() => {
    if (taxPreset === "custom") {
      return { rate: customTaxRate, name: "Tax" };
    }
    const p = TAX_PRESETS.find((x) => x.id === taxPreset);
    return { rate: p?.rate ?? 0, name: p?.name ?? "Tax" };
  }, [taxPreset, customTaxRate]);

  const currencyLocale =
    currency === "CAD" ? "en-CA" : currency === "USD" ? "en-US" : "fr-FR";

  const formatCurrency = useCallback(
    (amount: number) =>
      new Intl.NumberFormat(currencyLocale, {
        style: "currency",
        currency,
        minimumFractionDigits: 2,
      }).format(amount),
    [currency, currencyLocale]
  );

  const subtotal = useMemo(
    () => items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0),
    [items]
  );
  const discountAmount = subtotal * (discountPct / 100);
  const taxable = Math.max(0, subtotal - discountAmount);
  const taxAmount = taxable * (activeTax.rate / 100);
  const total = taxable + taxAmount;

  const addItem = () => {
    setItems((prev) => [
      ...prev,
      { id: Date.now(), description: "", quantity: 1, unitPrice: 0 },
    ]);
  };

  const removeItem = (id: number) => {
    setItems((prev) => (prev.length > 1 ? prev.filter((i) => i.id !== id) : prev));
  };

  const updateItem = (id: number, field: keyof LineItem, value: string | number) => {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  const applyTemplate = (templateId: string) => {
    const tpl = TEMPLATES.find((x) => x.id === templateId);
    if (!tpl) return;
    setItems(
      tpl.items.map((it, idx) => ({
        id: Date.now() + idx,
        description: it.description,
        quantity: it.quantity,
        unitPrice: it.unitPrice,
      }))
    );
  };

  /* ─── PDF Generation ─── */
  const generatePDF = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const primary: [number, number, number] = [37, 99, 235];

    const labels = {
      en: { inv: "INVOICE", from: "FROM", to: "BILL TO", sub: "Subtotal", tax: activeTax.name || "Tax", tot: "Total", due: "Balance Due", terms: "Terms" },
      fr: { inv: "FACTURE", from: "DE", to: "FACTURER À", sub: "Sous-total", tax: activeTax.name || "Taxe", tot: "Total", due: "Solde dû", terms: "Conditions" },
      es: { inv: "FACTURA", from: "DE", to: "FACTURAR A", sub: "Subtotal", tax: activeTax.name || "Impuesto", tot: "Total", due: "Saldo", terms: "Condiciones" },
    }[lang];

    // Header band
    doc.setFillColor(...primary);
    doc.rect(0, 0, pageWidth, 28, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.text(labels.inv, 14, 18);

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(`# ${invoiceMeta.number}`, pageWidth - 14, 12, { align: "right" });
    doc.text(invoiceMeta.date, pageWidth - 14, 18, { align: "right" });
    if (invoiceMeta.dueDate) {
      doc.text(`${t.dueDate}: ${invoiceMeta.dueDate}`, pageWidth - 14, 24, { align: "right" });
    }

    // From / To
    let y = 40;
    doc.setTextColor(100);
    doc.setFontSize(8);
    doc.setFont("helvetica", "bold");
    doc.text(labels.from, 14, y);
    doc.text(labels.to, pageWidth / 2 + 4, y);

    y += 6;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(20);
    doc.text(company.name || "Your Business", 14, y);
    doc.text(client.name || "Client", pageWidth / 2 + 4, y);

    y += 5;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(70);
    const leftLines = [
      company.address,
      company.city,
      company.email,
      company.phone,
      company.bn ? `BN: ${company.bn}` : "",
      company.gst ? `GST/HST: ${company.gst}` : "",
    ].filter(Boolean);
    const rightLines = [client.address, client.city, client.email].filter(Boolean);

    leftLines.forEach((line, i) => doc.text(line, 14, y + i * 4.5));
    rightLines.forEach((line, i) => doc.text(line, pageWidth / 2 + 4, y + i * 4.5));

    const tableStart = Math.max(y + leftLines.length * 4.5, y + rightLines.length * 4.5) + 10;

    const tableData = items.map((item) => [
      item.description || "—",
      String(item.quantity),
      formatCurrency(item.unitPrice),
      formatCurrency(item.quantity * item.unitPrice),
    ]);

    autoTable(doc, {
      startY: tableStart,
      head: [[t.description, t.qty, t.unitPrice, t.totalHT]],
      body: tableData,
      theme: "striped",
      headStyles: {
        fillColor: primary,
        textColor: 255,
        fontStyle: "bold",
        fontSize: 9,
      },
      bodyStyles: { fontSize: 9 },
      columnStyles: {
        0: { cellWidth: 88 },
        1: { cellWidth: 18, halign: "center" },
        2: { cellWidth: 35, halign: "right" },
        3: { cellWidth: 35, halign: "right" },
      },
      margin: { left: 14, right: 14 },
    });

    const finalY = (doc as any).lastAutoTable.finalY + 10;

    // Totals
    doc.setFontSize(10);
    doc.setTextColor(80);
    doc.setFont("helvetica", "normal");
    let ty = finalY;
    doc.text(labels.sub, pageWidth - 70, ty);
    doc.text(formatCurrency(subtotal), pageWidth - 14, ty, { align: "right" });
    ty += 6;
    if (discountPct > 0) {
      doc.text(`Discount (${discountPct}%)`, pageWidth - 70, ty);
      doc.text(`-${formatCurrency(discountAmount)}`, pageWidth - 14, ty, { align: "right" });
      ty += 6;
    }
    if (activeTax.rate > 0) {
      doc.text(`${labels.tax} (${activeTax.rate}%)`, pageWidth - 70, ty);
      doc.text(formatCurrency(taxAmount), pageWidth - 14, ty, { align: "right" });
      ty += 6;
    }
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(...primary);
    doc.text(labels.tot, pageWidth - 70, ty);
    doc.text(formatCurrency(total), pageWidth - 14, ty, { align: "right" });

    // Interac
    let notesY = ty + 12;
    if (company.interac) {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.setTextColor(30);
      doc.text("Interac e-Transfer:", 14, notesY);
      doc.setFont("helvetica", "normal");
      doc.text(company.interac, 50, notesY);
      notesY += 8;
    }

    if (invoiceMeta.notes) {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.setTextColor(100);
      doc.text(labels.terms, 14, notesY);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(60);
      const split = doc.splitTextToSize(invoiceMeta.notes, pageWidth - 28);
      doc.text(split, 14, notesY + 5);
    }

    // Watermark free
    if (plan === "free") {
      doc.setFontSize(36);
      doc.setTextColor(220, 220, 220);
      doc.setFont("helvetica", "bold");
      doc.text("FACTUREPRO FREE", pageWidth / 2, 155, {
        align: "center",
        angle: 28,
      });
    }

    // Footer
    doc.setFontSize(7);
    doc.setTextColor(150);
    doc.setFont("helvetica", "normal");
    const footer =
      plan === "pro"
        ? "Generated with FacturePro Pro"
        : "Generated with FacturePro Free – Upgrade to remove watermark";
    doc.text(footer, pageWidth / 2, 287, { align: "center" });

    doc.save(`invoice-${invoiceMeta.number}.pdf`);
  };

  const handleGenerate = () => {
    if (isLimitReached) {
      setShowUpgrade(true);
      return;
    }
    generatePDF();
    setToast(lang === "fr" ? "PDF téléchargé ✓" : lang === "es" ? "PDF descargado ✓" : "PDF downloaded ✓");
    setTimeout(() => setToast(null), 2500);
    const newCount = invoicesThisMonth + 1;
    setInvoicesThisMonth(newCount);
    setSavedInvoices((prev) =>
      [
        {
          id: Date.now().toString(),
          number: invoiceMeta.number,
          clientName: client.name || "Client",
          total,
          date: invoiceMeta.date,
          createdAt: new Date().toISOString(),
        },
        ...prev,
      ].slice(0, 50)
    );
    setInvoiceMeta((prev) => ({
      ...prev,
      number: `INV-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9000) + 1000)}`,
    }));
  };

  const handleUpgrade = async (selected: "monthly" | "yearly") => {
    setLoadingCheckout(true);
    try {
      const res = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: selected }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        alert(data.error || "Checkout error. Check Stripe configuration.");
        setLoadingCheckout(false);
      }
    } catch {
      alert("Network error. Please try again.");
      setLoadingCheckout(false);
    }
  };

  /* ───────────────────────── Render ───────────────────────── */
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <div
            className="flex items-center gap-2.5 cursor-pointer shrink-0"
            onClick={() => setView("app")}
          >
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center shadow-sm">
              <span className="text-white font-bold text-sm">F</span>
            </div>
            <div className="hidden sm:block">
              <h1 className="font-bold text-base text-slate-900 leading-tight">{t.brand}</h1>
              <p className="text-[10px] text-slate-500">
                {plan === "pro" ? (
                  <span className="text-emerald-600 font-semibold">{t.proBadge}</span>
                ) : (
                  t.free
                )}
              </p>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-0.5">
            {(["app", "history", "pricing"] as View[]).map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                  view === v
                    ? "bg-slate-100 text-slate-900"
                    : "text-slate-600 hover:bg-slate-50"
                }`}
              >
                {v === "app" ? t.create : v === "history" ? t.history : t.pricing}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value as Lang)}
              className="text-xs border border-slate-200 rounded-md px-2 py-1.5 bg-white"
              aria-label={t.language}
            >
              <option value="en">EN</option>
              <option value="fr">FR</option>
              <option value="es">ES</option>
            </select>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as Currency)}
              className="text-xs border border-slate-200 rounded-md px-2 py-1.5 bg-white"
              aria-label={t.currency}
            >
              <option value="CAD">CAD $</option>
              <option value="USD">USD $</option>
              <option value="EUR">EUR €</option>
            </select>

            {plan === "free" && (
              <span className="hidden lg:inline text-xs text-slate-500">
                {invoicesThisMonth}/{FREE_LIMIT}
              </span>
            )}

            {plan === "free" ? (
              <button
                onClick={() => setView("pricing")}
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-3 py-1.5 rounded-lg text-sm font-semibold shadow-sm transition"
              >
                {t.upgrade}
              </button>
            ) : (
              <span className="bg-emerald-50 text-emerald-700 text-xs font-semibold px-2.5 py-1 rounded-full border border-emerald-100">
                {t.proAccount}
              </span>
            )}
          </div>
        </div>
      </header>

      {/* Upgrade modal */}
      {showUpgrade && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <h3 className="text-xl font-bold text-slate-900 mb-2">{t.limitReachedTitle}</h3>
            <p className="text-slate-600 text-sm mb-6">
              {t.limitReachedText.replace("{limit}", String(FREE_LIMIT))}
            </p>
            <div className="space-y-3">
              <button
                disabled={loadingCheckout}
                onClick={() => handleUpgrade("monthly")}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white py-3 rounded-xl font-semibold"
              >
                {loadingCheckout ? "…" : t.monthly}
              </button>
              <button
                disabled={loadingCheckout}
                onClick={() => handleUpgrade("yearly")}
                className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white py-3 rounded-xl font-semibold"
              >
                {loadingCheckout ? "…" : t.yearly}{" "}
                <span className="text-indigo-200 text-sm">{t.yearlyBonus}</span>
              </button>
              <button
                onClick={() => setShowUpgrade(false)}
                className="w-full text-slate-500 py-2 text-sm hover:text-slate-700"
              >
                {t.continueFree}
              </button>
            </div>
          </div>
        </div>
      )}

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* ───── PRICING ───── */}
        {view === "pricing" && (
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold text-slate-900 mb-2">{t.pricingTitle}</h2>
              <p className="text-slate-600">{t.pricingSub}</p>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                <div className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-1">
                  {t.freePlan}
                </div>
                <div className="text-4xl font-bold text-slate-900 mb-1">{t.freePrice}</div>
                <p className="text-slate-500 text-sm mb-6">{t.freeDesc}</p>
                <ul className="space-y-2.5 text-sm text-slate-700 mb-8">
                  {[t.feature5, t.featureTax, t.featurePdf, t.featureInterac].map((f) => (
                    <li key={f} className="flex gap-2">
                      <span className="text-emerald-500">✓</span> {f}
                    </li>
                  ))}
                  {[t.featureWatermark, t.featureLogo].map((f) => (
                    <li key={f} className="flex gap-2 text-slate-400">
                      <span>✗</span> {f}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => setView("app")}
                  className="w-full border border-slate-300 text-slate-700 py-2.5 rounded-xl font-medium hover:bg-slate-50"
                >
                  {t.continueFree}
                </button>
              </div>

              <div className="bg-gradient-to-b from-blue-600 to-indigo-700 rounded-2xl p-6 shadow-xl text-white relative">
                <div className="absolute top-4 right-4 bg-amber-400 text-amber-900 text-xs font-bold px-2.5 py-1 rounded-full">
                  {t.popular}
                </div>
                <div className="text-sm font-semibold text-blue-100 uppercase tracking-wide mb-1">
                  {t.proPlan}
                </div>
                <div className="flex items-end gap-1 mb-1">
                  <span className="text-4xl font-bold">{t.proPrice}</span>
                  <span className="text-blue-200 mb-1">{t.perMonth}</span>
                </div>
                <p className="text-blue-100 text-sm mb-1">{t.orYearly}</p>
                <p className="text-blue-200 text-xs mb-6">{t.cancelAnytime}</p>
                <ul className="space-y-2.5 text-sm mb-8">
                  {[
                    t.featureUnlimited,
                    t.featureNoWatermark,
                    t.featureLogoColors,
                    t.feature3Templates,
                    t.featureHistory,
                    t.featureSupport,
                  ].map((f) => (
                    <li key={f} className="flex gap-2">
                      <span className="text-emerald-300">✓</span> {f}
                    </li>
                  ))}
                </ul>
                <div className="space-y-2">
                  <button
                    disabled={loadingCheckout}
                    onClick={() => handleUpgrade("monthly")}
                    className="w-full bg-white text-blue-700 py-2.5 rounded-xl font-semibold hover:bg-blue-50 disabled:opacity-60"
                  >
                    {t.startMonthly}
                  </button>
                  <button
                    disabled={loadingCheckout}
                    onClick={() => handleUpgrade("yearly")}
                    className="w-full bg-blue-500/30 text-white py-2.5 rounded-xl font-medium hover:bg-blue-500/40 border border-white/20 disabled:opacity-60"
                  >
                    {t.startYearly}
                  </button>
                </div>
              </div>
            </div>
            <div className="mt-10 text-center text-xs text-slate-400 flex flex-wrap justify-center gap-6">
              <span>🔒 {t.secure}</span>
              <span>🇨🇦 {t.hosted}</span>
              <span>📄 {t.compliant}</span>
            </div>
          </div>
        )}

        {/* ───── HISTORY ───── */}
        {view === "history" && (
          <div>
            <div className="flex items-center justify-between mb-6 flex-wrap gap-2">
              <h2 className="text-2xl font-bold text-slate-900">{t.historyTitle}</h2>
              {plan === "free" && (
                <span className="text-xs bg-amber-50 text-amber-700 px-3 py-1 rounded-full">
                  {t.historyLimit}
                </span>
              )}
            </div>
            {savedInvoices.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
                <p className="text-slate-500 mb-4">{t.noInvoices}</p>
                <button
                  onClick={() => setView("app")}
                  className="text-blue-600 font-medium hover:underline"
                >
                  {t.createFirst}
                </button>
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-slate-50 text-slate-600">
                      <tr>
                        <th className="text-left px-5 py-3 font-medium">{t.number}</th>
                        <th className="text-left px-5 py-3 font-medium">{t.client}</th>
                        <th className="text-left px-5 py-3 font-medium">{t.date}</th>
                        <th className="text-right px-5 py-3 font-medium">{t.totalTTC}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {savedInvoices.map((inv) => (
                        <tr key={inv.id} className="border-t border-slate-100 hover:bg-slate-50">
                          <td className="px-5 py-3 font-medium text-slate-900">{inv.number}</td>
                          <td className="px-5 py-3 text-slate-600">{inv.clientName}</td>
                          <td className="px-5 py-3 text-slate-500">{inv.date}</td>
                          <td className="px-5 py-3 text-right font-medium">
                            {formatCurrency(inv.total)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ───── APP ───── */}
        {view === "app" && (
          <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
            {/* Form – 3 cols */}
            <div className="xl:col-span-3 space-y-5">
              {/* Templates */}
              <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
                <h2 className="text-sm font-semibold text-slate-700 mb-3">{t.template}</h2>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {TEMPLATES.map((tpl) => (
                    <button
                      key={tpl.id}
                      onClick={() => applyTemplate(tpl.id)}
                      className="text-left border border-slate-200 hover:border-blue-400 hover:bg-blue-50 rounded-lg p-3 transition"
                    >
                      <div className="font-medium text-sm text-slate-800">
                        {tpl.label[lang]}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">{tpl.desc[lang]}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Company + Client */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
                  <h2 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
                    <span className="w-6 h-6 bg-blue-100 text-blue-700 rounded text-xs flex items-center justify-center font-bold">
                      1
                    </span>
                    {t.yourCompany}
                  </h2>
                  <div className="space-y-2.5">
                    <input
                      placeholder={t.companyName}
                      value={company.name}
                      onChange={(e) => setCompany({ ...company, name: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                    />
                    <input
                      placeholder={t.address}
                      value={company.address}
                      onChange={(e) => setCompany({ ...company, address: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                    />
                    <input
                      placeholder={t.city}
                      value={company.city}
                      onChange={(e) => setCompany({ ...company, city: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        placeholder={t.email}
                        value={company.email}
                        onChange={(e) => setCompany({ ...company, email: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                      />
                      <input
                        placeholder={t.phone}
                        value={company.phone}
                        onChange={(e) => setCompany({ ...company, phone: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        placeholder={t.siret}
                        value={company.bn}
                        onChange={(e) => setCompany({ ...company, bn: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                      />
                      <input
                        placeholder={t.gstNumber}
                        value={company.gst}
                        onChange={(e) => setCompany({ ...company, gst: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                      />
                    </div>
                    <input
                      placeholder={t.interac}
                      value={company.interac}
                      onChange={(e) => setCompany({ ...company, interac: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                    />
                  </div>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
                  <h2 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
                    <span className="w-6 h-6 bg-blue-100 text-blue-700 rounded text-xs flex items-center justify-center font-bold">
                      2
                    </span>
                    {t.clientSection}
                  </h2>
                  <div className="space-y-2.5">
                    <input
                      placeholder={t.clientName}
                      value={client.name}
                      onChange={(e) => setClient({ ...client, name: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                    />
                    <input
                      placeholder={t.address}
                      value={client.address}
                      onChange={(e) => setClient({ ...client, address: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                    />
                    <input
                      placeholder={t.city}
                      value={client.city}
                      onChange={(e) => setClient({ ...client, city: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                    />
                    <input
                      placeholder={t.email}
                      value={client.email}
                      onChange={(e) => setClient({ ...client, email: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                    />
                  </div>
                </div>
              </div>

              {/* Invoice meta */}
              <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
                <h2 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <span className="w-6 h-6 bg-blue-100 text-blue-700 rounded text-xs flex items-center justify-center font-bold">
                    3
                  </span>
                  {t.invoiceSection}
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs text-slate-500 mb-1 block">{t.invoiceNumber}</label>
                    <input
                      value={invoiceMeta.number}
                      onChange={(e) =>
                        setInvoiceMeta({ ...invoiceMeta, number: e.target.value })
                      }
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-500 mb-1 block">{t.date}</label>
                    <input
                      type="date"
                      value={invoiceMeta.date}
                      onChange={(e) =>
                        setInvoiceMeta({ ...invoiceMeta, date: e.target.value })
                      }
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-500 mb-1 block">{t.dueDate}</label>
                    <input
                      type="date"
                      value={invoiceMeta.dueDate}
                      onChange={(e) =>
                        setInvoiceMeta({ ...invoiceMeta, dueDate: e.target.value })
                      }
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                    />
                  </div>
                </div>
              </div>

              {/* Line items */}
              <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-semibold text-slate-800 flex items-center gap-2">
                    <span className="w-6 h-6 bg-blue-100 text-blue-700 rounded text-xs flex items-center justify-center font-bold">
                      4
                    </span>
                    {t.items}
                  </h2>
                  <button
                    onClick={addItem}
                    className="text-sm text-blue-600 hover:text-blue-700 font-medium"
                  >
                    {t.addLine}
                  </button>
                </div>
                <div className="space-y-2.5">
                  {items.map((item) => (
                    <div
                      key={item.id}
                      className="flex flex-col sm:flex-row gap-2 items-start sm:items-center"
                    >
                      <input
                        placeholder={t.description}
                        value={item.description}
                        onChange={(e) =>
                          updateItem(item.id, "description", e.target.value)
                        }
                        className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-sm w-full"
                      />
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={item.quantity}
                        onChange={(e) =>
                          updateItem(item.id, "quantity", parseFloat(e.target.value) || 0)
                        }
                        className="w-20 px-3 py-2 border border-slate-200 rounded-lg text-sm"
                      />
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={item.unitPrice}
                        onChange={(e) =>
                          updateItem(item.id, "unitPrice", parseFloat(e.target.value) || 0)
                        }
                        className="w-28 px-3 py-2 border border-slate-200 rounded-lg text-sm"
                      />
                      <div className="w-24 text-right text-sm font-medium text-slate-700 py-2">
                        {formatCurrency(item.quantity * item.unitPrice)}
                      </div>
                      <button
                        onClick={() => removeItem(item.id)}
                        className="text-slate-400 hover:text-red-500 p-1 text-sm"
                        title={t.remove}
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Notes */}
              <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
                <h2 className="font-semibold text-slate-800 mb-3">{t.notes}</h2>
                <textarea
                  rows={3}
                  value={invoiceMeta.notes}
                  onChange={(e) =>
                    setInvoiceMeta({ ...invoiceMeta, notes: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm resize-none"
                />
              </div>
            </div>

            {/* Sidebar – Preview + Summary (2 cols) */}
            <div className="xl:col-span-2 space-y-5">
              {/* Live preview card */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden sticky top-20">
                <div className="bg-slate-800 text-white px-4 py-2.5 text-xs font-medium flex items-center justify-between">
                  <span>{t.livePreview}</span>
                  <span className="opacity-70">{invoiceMeta.number}</span>
                </div>
                <div className="p-5 preview-scroll max-h-[420px] overflow-y-auto text-sm">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <div className="text-lg font-bold text-blue-600">
                        {lang === "fr" ? "FACTURE" : lang === "es" ? "FACTURA" : "INVOICE"}
                      </div>
                      <div className="text-xs text-slate-500 mt-1">
                        {invoiceMeta.date}
                        {invoiceMeta.dueDate && ` · Due ${invoiceMeta.dueDate}`}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold text-slate-900">
                        {company.name || "Your Business"}
                      </div>
                      <div className="text-xs text-slate-500">
                        {[company.city, company.email].filter(Boolean).join(" · ")}
                      </div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="text-[10px] uppercase tracking-wide text-slate-400 font-semibold">
                      {t.billTo}
                    </div>
                    <div className="font-medium text-slate-800">
                      {client.name || "—"}
                    </div>
                    <div className="text-xs text-slate-500">
                      {[client.city, client.email].filter(Boolean).join(" · ")}
                    </div>
                  </div>

                  <table className="w-full text-xs mb-4">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500">
                        <th className="text-left py-1.5 font-medium">{t.description}</th>
                        <th className="text-right py-1.5 font-medium">{t.qty}</th>
                        <th className="text-right py-1.5 font-medium">{t.totalHT}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {items.map((item) => (
                        <tr key={item.id} className="border-b border-slate-50">
                          <td className="py-1.5 text-slate-700">
                            {item.description || "—"}
                          </td>
                          <td className="py-1.5 text-right text-slate-600">
                            {item.quantity}
                          </td>
                          <td className="py-1.5 text-right font-medium">
                            {formatCurrency(item.quantity * item.unitPrice)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between text-slate-600">
                      <span>{t.totalHT}</span>
                      <span>{formatCurrency(subtotal)}</span>
                    </div>
                    {discountPct > 0 && (
                      <div className="flex justify-between text-emerald-600">
                        <span>{lang === "fr" ? "Remise" : lang === "es" ? "Descuento" : "Discount"} ({discountPct}%)</span>
                        <span>-{formatCurrency(discountAmount)}</span>
                      </div>
                    )}
                    {activeTax.rate > 0 && (
                      <div className="flex justify-between text-slate-600">
                        <span>
                          {activeTax.name} ({activeTax.rate}%)
                        </span>
                        <span>{formatCurrency(taxAmount)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-base font-bold text-blue-700 pt-1 border-t border-slate-100">
                      <span>{t.total}</span>
                      <span>{formatCurrency(total)}</span>
                    </div>
                  </div>

                  {company.interac && (
                    <div className="mt-3 text-[11px] text-slate-500">
                      Interac: {company.interac}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="border-t border-slate-100 p-4 space-y-3">
                  <div>
                    <label className="text-xs text-slate-500 mb-1 block">{t.taxRate}</label>
                    <select
                      value={taxPreset}
                      onChange={(e) => setTaxPreset(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                    >
                      {TAX_PRESETS.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.label}
                        </option>
                      ))}
                    </select>
                    {taxPreset === "custom" && (
                      <input
                        type="number"
                        min="0"
                        step="0.001"
                        value={customTaxRate}
                        onChange={(e) =>
                          setCustomTaxRate(parseFloat(e.target.value) || 0)
                        }
                        placeholder="Custom %"
                        className="w-full mt-2 px-3 py-2 border border-slate-200 rounded-lg text-sm"
                      />
                    )}
                  </div>

                  <div>
                    <label className="text-xs text-slate-500 mb-1 block">
                      {lang === "fr" ? "Remise %" : lang === "es" ? "Descuento %" : "Discount %"}
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      value={discountPct}
                      onChange={(e) => setDiscountPct(parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                    />
                  </div>

                  {plan === "free" && (
                    <div className="text-xs text-center text-slate-500 bg-slate-50 rounded-lg py-1.5">
                      {invoicesThisMonth}/{FREE_LIMIT} {t.usedThisMonth}
                    </div>
                  )}

                  <button
                    onClick={handleGenerate}
                    className={`w-full py-3 rounded-xl font-semibold shadow-sm transition ${
                      isLimitReached
                        ? "bg-amber-500 hover:bg-amber-600 text-white"
                        : "bg-blue-600 hover:bg-blue-700 text-white"
                    }`}
                  >
                    {isLimitReached ? t.upgradeToContinue : t.downloadPdf}
                  </button>

                  {plan === "free" && (
                    <p className="text-[11px] text-slate-400 text-center">
                      {t.freeWatermark}
                    </p>
                  )}
                </div>
              </div>

              {plan === "free" && (
                <div className="bg-gradient-to-br from-indigo-600 to-blue-700 rounded-xl p-5 text-white shadow-lg">
                  <h3 className="font-bold text-lg mb-1">{t.goPro}</h3>
                  <p className="text-blue-100 text-sm mb-3">{t.goProDesc}</p>
                  <div className="text-2xl font-bold mb-3">
                    9 $<span className="text-base font-normal text-blue-200">{t.perMonth}</span>
                  </div>
                  <button
                    onClick={() => setView("pricing")}
                    className="w-full bg-white text-indigo-700 py-2.5 rounded-lg font-semibold text-sm hover:bg-blue-50"
                  >
                    {t.seePricing}
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white px-5 py-3 rounded-xl shadow-lg text-sm font-medium animate-fade-in">
          {toast}
        </div>
      )}

      <footer className="border-t border-slate-200 mt-12 py-8 text-center text-sm text-slate-500">
        <p className="font-medium text-slate-700 mb-1">{t.brand}</p>
        <p>{t.footerTagline}</p>
        <p className="mt-3 text-xs text-slate-400">
          © {new Date().getFullYear()} {t.brand} – {t.rights}
        </p>
      </footer>
    </div>
  );
}
